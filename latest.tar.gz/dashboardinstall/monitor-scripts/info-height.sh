#!/bin/bash
sudo docker exec miner miner info height > /var/dashboard/statuses/infoheight
